<?php
namespace App\Repositories;

interface RssFeedItemRepositoryInterface extends SingleKeyModelRepositoryInterface
{

}