<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1><a href="<?php echo URL::action('RssFeedController@index'); ?>">Feeds List</a></h1>
        <a class="btn btn-default" href="<?php echo URL::action('RssFeedController@create'); ?>" role="button">Create</a>
        <hr>
        <?php if(session('message-success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message-success')); ?>

            </div>
        <?php endif; ?>
        <form class="form-inline" method="GET" action="<?php echo URL::action('RssFeedController@index'); ?>">
            <div class="form-group">
                <input type="text" class="form-control" name="search_category" id="search_category" placeholder="Category Name" value="<?php echo e($search_category); ?>">
            </div>
            <button type="submit" class="btn btn-default">Search</button>
        </form>
        <hr>
        <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="model-item panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title"><?php echo e($model->title); ?></h3>
            </div>
            <div class="panel-body">
                <p>Link: <?php echo e($model->link); ?></p>
                <p>Categories: <?php echo e($model->categories); ?></p>
                <p>Publish Date: <?php echo e($model->pub_date); ?></p>
                <p>GUID: <?php echo e($model->guid); ?></p>
            </div>
            <div class="panel-footer">
                <div class="text-right">
                    <a class="btn btn-default" href="<?php echo URL::action('RssFeedController@show', $model->id); ?>" role="button">Edit</a>
                    <a class="btn btn-default delete-button" href="#" data-delete-url="<?php echo URL::action('RssFeedController@destroy', $model->id); ?>" role="button">Delete</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($search_category)): ?>
            <?php echo e($models->appends(['search_category' => $search_category])->links()); ?>

        <?php else: ?>
            <?php echo e($models->links()); ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>