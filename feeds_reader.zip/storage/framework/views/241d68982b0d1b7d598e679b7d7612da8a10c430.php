<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if( $isNew ): ?>
            <h2>New</h2>
        <?php else: ?>
            <h2>Edit item <?php echo e($model->id); ?></h2>
        <?php endif; ?>
        <a class="btn btn-default" href="<?php echo URL::action('RssFeedController@index'); ?>" role="button">Back</a>
        <hr>
        <?php if(session('message-success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message-success')); ?>

            </div>
        <?php endif; ?>
        <form action="<?php if($isNew): ?> <?php echo action('RssFeedController@store'); ?> <?php else: ?> <?php echo action('RssFeedController@update', [$model->id]); ?> <?php endif; ?>" method="POST" enctype="multipart/form-data">
            <?php if( !$isNew ): ?> <input type="hidden" name="_method" value="PUT"> <?php endif; ?>
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="title">Title</label>
                <input type="text" name="title" class="form-control" id="title" placeholder="Title"
                        value="<?php echo e(old('title') ? old('title') : $model->title); ?>">
            </div>
            <div class="form-group">
                <label for="link">Link</label>
                <input type="text" name="link" class="form-control" id="link" placeholder="Link"
                       value="<?php echo e(old('link') ? old('link') : $model->link); ?>">
            </div>
            <div class="form-group">
                <label for="categories">Categories</label>
                <input type="text" name="categories" class="form-control" id="categories" placeholder="Categories"
                       value="<?php echo e(old('categories') ? old('categories') : $model->categories); ?>">
            </div>
            <div class="form-group">
                <label for="guid">GUID</label>
                <input type="text" name="guid" class="form-control" id="guid" placeholder="GUID"
                       value="<?php echo e(old('guid') ? old('guid') : $model->guid); ?>">
            </div>
            <div class="form-group">
                <div class="form-group">
                    <label for="pub_date">Publish Date <?php echo e($model->pub_date); ?></label>
                    <div class='input-group date' id='pub_date'>
                        <input type='text' class="form-control" name="pub_date" value="<?php echo e(old('pub_date') ? old('pub_date') : $model->pub_date); ?>"/>
                        <span class="input-group-addon">
                            <span class="glyphicon glyphicon-calendar"></span>
                        </span>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-default">Submit</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(function () {
            $('#pub_date').datetimepicker({
                'format': 'YYYY-MM-DD HH:mm:ss'
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>